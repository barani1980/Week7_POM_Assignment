package EditLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class EL03_MyHomePage extends Leaftaps_launch  {

	public EL03_MyHomePage (ChromeDriver driver) {
		this.driver = driver;
	}
	
	public EL04_FindLeadsPage clickLeadsTab() throws InterruptedException {
		driver.findElementByLinkText("Leads").click();
		Thread.sleep(3000);
		return new EL04_FindLeadsPage(driver);
	}
}
