package EditLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class EL07_AgainViewLeadPage extends Leaftaps_launch {

	public EL07_AgainViewLeadPage (ChromeDriver driver) {
		this.driver = driver;
	}
	
	public EL07_AgainViewLeadPage printTitle() {
		System.out.println("Edited page title = " + driver.getTitle());
		System.out.println("Edited company name = " + driver.findElementById("viewLead_companyName_sp").getText());
		return this;
	}
}
