package EditLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class EL06_EditLeadPage extends Leaftaps_launch {

	public EL06_EditLeadPage (ChromeDriver driver) {
		this.driver = driver;
	}
	
	public EL07_AgainViewLeadPage updateCompany(String companyName) {
		
		driver.findElementById("updateLeadForm_companyName").clear();
		driver.findElementById("updateLeadForm_companyName").sendKeys(companyName);
		driver.findElementByName("submitButton").click();
		return new EL07_AgainViewLeadPage(driver);
	}
}
