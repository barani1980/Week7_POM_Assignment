package EditLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class EL05_ViewLeadPage extends Leaftaps_launch {
	
	public EL05_ViewLeadPage (ChromeDriver driver) {
		this.driver = driver;
	}
	
	public EL06_EditLeadPage clickEditButton() {
	
		driver.findElementByLinkText("Edit").click();
		return new EL06_EditLeadPage(driver);
	}
}
