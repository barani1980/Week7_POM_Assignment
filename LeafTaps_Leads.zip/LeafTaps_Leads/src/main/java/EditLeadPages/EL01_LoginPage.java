package EditLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class EL01_LoginPage extends Leaftaps_launch {

	public EL01_LoginPage (ChromeDriver driver) {
		this.driver = driver;
	}
	
	public EL01_LoginPage enterUserName(String uname) {
		driver.findElementById("username").sendKeys(uname);
		return this;
	}
	
	public EL01_LoginPage enterPassword(String pword) {
		driver.findElementById("password").sendKeys(pword);
		return this;
	}
	
	public EL02_HomePage clickSubmit() {
		driver.findElementByClassName("decorativeSubmit").click();
		return new EL02_HomePage(driver);
	}
	
	
}
