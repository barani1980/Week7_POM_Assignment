package EditLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class EL02_HomePage extends Leaftaps_launch {

	public EL02_HomePage (ChromeDriver driver) {
		this.driver = driver;
	}
	
	public EL03_MyHomePage clickCRMSFA() throws InterruptedException {
		driver.findElementByLinkText("CRM/SFA").click();
		Thread.sleep(2000);
		return new EL03_MyHomePage (driver);
	}
}
