package CreateLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class CL01_LoginPage extends Leaftaps_launch {

	public CL01_LoginPage(ChromeDriver driver) {
		this.driver = driver;
	}
	public CL01_LoginPage enterUserName(String uname) {
		driver.findElementById("username").sendKeys(uname);
		return this;
	}
	
	public CL01_LoginPage enterPassword(String pword) {
		driver.findElementById("password").sendKeys(pword);
		return this;
	}
	
	public CL02_HomePage clickSubmit() {
		driver.findElementByClassName("decorativeSubmit").click();
		return new CL02_HomePage(driver);
	}
	
	
}
