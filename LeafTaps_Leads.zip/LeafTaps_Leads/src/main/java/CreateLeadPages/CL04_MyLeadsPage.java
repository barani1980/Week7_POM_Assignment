package CreateLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class CL04_MyLeadsPage extends Leaftaps_launch {

	public  CL04_MyLeadsPage (ChromeDriver driver) {
		this.driver = driver;
	}
	
	public CL05_CreateLeadPage clickCreateLead() {
		driver.findElementByLinkText("Create Lead").click();
		return new CL05_CreateLeadPage(driver) ;
	}
}
