package CreateLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class CL06_ViewLeadPage extends Leaftaps_launch {

	public  CL06_ViewLeadPage (ChromeDriver driver) {
		this.driver = driver;
	}
	
	public CL06_ViewLeadPage printTitle() {
		System.out.println(driver.getTitle());
		return this;
	}
}
