package CreateLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class CL03_MyHomePage extends Leaftaps_launch  {

	public  CL03_MyHomePage (ChromeDriver driver) {
		this.driver = driver;
	}
	public CL04_MyLeadsPage clickLeadsTab() throws InterruptedException {
		driver.findElementByLinkText("Leads").click();
		Thread.sleep(3000);
		return new CL04_MyLeadsPage(driver);
	}
}
