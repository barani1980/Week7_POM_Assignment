package CreateLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class CL05_CreateLeadPage extends Leaftaps_launch {
	
	public  CL05_CreateLeadPage (ChromeDriver driver) {
		this.driver = driver;
	}
	
	public CL05_CreateLeadPage enterCompanyName (String compName) {
		driver.findElementById("createLeadForm_companyName").sendKeys(compName);
		return this;
	}
	
	public CL05_CreateLeadPage enterFirstName (String firstName) {
		driver.findElementById("createLeadForm_firstName").sendKeys(firstName);
		return this;
	}
	
	public CL05_CreateLeadPage enterlastName (String lastName) {
		driver.findElementById("createLeadForm_lastName").sendKeys(lastName);
		return this;
	}	
		
	public CL06_ViewLeadPage clickSubmit () {
		driver.findElementByName("submitButton").click();
		return new CL06_ViewLeadPage(driver);
	}	
		
		
		
	
}
