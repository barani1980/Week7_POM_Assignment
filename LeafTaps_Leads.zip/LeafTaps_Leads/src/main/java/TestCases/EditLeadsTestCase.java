package TestCases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import EditLeadPages.EL01_LoginPage;
import ProjectBase.Leaftaps_launch;

public class EditLeadsTestCase extends Leaftaps_launch {

	@BeforeTest
	public void setFileName() {
		excelFileName = "EditLead";
	}

	
	@Test(dataProvider = "fetchExcel")
	public void testEditLead(String phoneNumber, String companyName) throws InterruptedException {
	
		EL01_LoginPage lp = new EL01_LoginPage(driver);
		lp
		.enterUserName("demosalesmanager")
		.enterPassword("crmsfa")
		.clickSubmit()
		.clickCRMSFA()
		.clickLeadsTab()
		.clickFindLeads(phoneNumber)
		.clickEditButton()
		.updateCompany(companyName)
		.printTitle();
		
	}
}
