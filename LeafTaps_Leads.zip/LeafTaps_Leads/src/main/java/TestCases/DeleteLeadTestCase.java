package TestCases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import DeleteLeadPages.DL01_LoginPage;
import ProjectBase.Leaftaps_launch;

public class DeleteLeadTestCase extends Leaftaps_launch {


	@BeforeTest
	public void setFileName() {
		excelFileName = "DeleteLead";
	}

	
	@Test(dataProvider = "fetchExcel")
	public void testDeleteLead(String phoneNumber) throws InterruptedException {
	
		DL01_LoginPage dp = new DL01_LoginPage(driver);
		dp
		.enterUserName("demosalesmanager")
		.enterPassword("crmsfa")
		.clickSubmit()
		.clickCRMSFA()
		.clickLeadsTab()
		.findTheLeadToDelete(phoneNumber)
		.clickDeleteButton()
		.confirmDeletion();
		
	}
}
