package TestCases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import CreateLeadPages.CL01_LoginPage;
import ProjectBase.Leaftaps_launch;

public class CreateLeadsTestCase extends Leaftaps_launch {

	@BeforeTest
	public void setFileName() {
		excelFileName = "CreateLead";
	}

	
	@Test(dataProvider = "fetchExcel")
	public void testCreatelead(String compName, String firstName, String lastName) throws InterruptedException {
		
		CL01_LoginPage lp = new CL01_LoginPage(driver);
		lp
		.enterUserName("demosalesmanager")
		.enterPassword("crmsfa")
		.clickSubmit()
		.clickCRMSFA()
		.clickLeadsTab()
		.clickCreateLead()
		.enterCompanyName(compName)
		.enterFirstName(firstName)
		.enterlastName(lastName)
		.clickSubmit()
		.printTitle();
	}
}
