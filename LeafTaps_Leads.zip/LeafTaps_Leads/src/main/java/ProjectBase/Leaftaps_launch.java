package ProjectBase;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Leaftaps_launch {

	public ChromeDriver driver;
	public String excelFileName;
	public String leadID;
	
	@BeforeMethod
	public void startApplication() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
	
	
	@AfterMethod
	public void closeApplication() {
		driver.close();
	}
	
	@DataProvider(name = "fetchExcel")
	public String[][] sendData() throws IOException  {
		ReadExcelData red = new ReadExcelData();
		String[][] data = red.readData(excelFileName);	
		return 	data;
	}
}
