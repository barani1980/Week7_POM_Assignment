package DeleteLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class DL06_AgainViewLeadsPage extends Leaftaps_launch  {

	DL06_AgainViewLeadsPage(String leadID, ChromeDriver driver) {
		
		this.leadID = leadID;
		this.driver = driver;
	}
	
	public DL06_AgainViewLeadsPage confirmDeletion() throws InterruptedException {
		driver.findElementByLinkText("Find Leads").click();
		driver.findElementByXPath("//input[@name='id']").sendKeys(leadID);
		Thread.sleep(2000);
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(3000);
		String text = driver.findElementByClassName("x-paging-info").getText();
		if (text.equalsIgnoreCase("No records to display")) {
			System.out.println("Lead deleted successfully");
		} else {
			System.out.println("Lead not deleted");
		}
		
		
		return this;
	}
}
