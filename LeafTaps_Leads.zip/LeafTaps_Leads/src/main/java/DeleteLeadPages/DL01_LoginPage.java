package DeleteLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class DL01_LoginPage extends Leaftaps_launch {

	public DL01_LoginPage(ChromeDriver driver) {
		this.driver = driver;
	}
	
	public DL01_LoginPage enterUserName(String uname) {
		driver.findElementById("username").sendKeys(uname);
		return this;
	}
	
	public DL01_LoginPage enterPassword(String pword) {
		driver.findElementById("password").sendKeys(pword);
		return this;
	}
	
	public DL02_HomePage clickSubmit() {
		driver.findElementByClassName("decorativeSubmit").click();
		return new DL02_HomePage(driver);
	}
	
	
}
