package DeleteLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class DL02_HomePage extends Leaftaps_launch {

	public DL02_HomePage (ChromeDriver driver) {
		this.driver = driver;
	}
	
	public DL03_MyHomePage clickCRMSFA() throws InterruptedException {
		driver.findElementByLinkText("CRM/SFA").click();
		Thread.sleep(2000);
		return new DL03_MyHomePage (driver);
	}
}
