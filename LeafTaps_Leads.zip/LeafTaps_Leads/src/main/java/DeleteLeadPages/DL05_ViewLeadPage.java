package DeleteLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class DL05_ViewLeadPage extends Leaftaps_launch {

	DL05_ViewLeadPage(String leadID, ChromeDriver driver) {
		this.leadID = leadID;
		this.driver = driver;
	}
	public DL06_AgainViewLeadsPage clickDeleteButton() throws InterruptedException {
		driver.findElementByLinkText("Delete").click();
		Thread.sleep(2000);
		return new DL06_AgainViewLeadsPage(leadID, driver);
	}
}
