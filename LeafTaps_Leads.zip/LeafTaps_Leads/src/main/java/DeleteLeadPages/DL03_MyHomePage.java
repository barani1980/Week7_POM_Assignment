package DeleteLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class DL03_MyHomePage extends Leaftaps_launch  {

	public DL03_MyHomePage (ChromeDriver driver) {
		this.driver = driver;
	}
	
	public DL04_FindLeadsPage clickLeadsTab() throws InterruptedException {
		driver.findElementByLinkText("Leads").click();
		Thread.sleep(3000);
		return new DL04_FindLeadsPage(driver);
	}
}
