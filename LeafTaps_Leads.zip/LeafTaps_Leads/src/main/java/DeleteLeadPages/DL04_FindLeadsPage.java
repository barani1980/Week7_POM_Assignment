package DeleteLeadPages;

import org.openqa.selenium.chrome.ChromeDriver;

import ProjectBase.Leaftaps_launch;

public class DL04_FindLeadsPage extends Leaftaps_launch {
	
	public DL04_FindLeadsPage (ChromeDriver driver) {
		this.driver = driver;
	}
	
	public DL05_ViewLeadPage findTheLeadToDelete(String phoneNo) throws InterruptedException {
		
		driver.findElementByLinkText("Find Leads").click();
		driver.findElementByXPath("//span[text()='Phone']").click();
		driver.findElementByXPath("//input[@name='phoneNumber']").sendKeys(phoneNo);
		driver.findElementByXPath("//button[text()='Find Leads']").click();
		Thread.sleep(2000);
		leadID = driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").getText();
		driver.findElementByXPath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a").click();
		return new DL05_ViewLeadPage(leadID, driver);
	}	
}
